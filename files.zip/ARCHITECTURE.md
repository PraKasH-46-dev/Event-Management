# System Architecture Documentation

## 📐 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     CLIENT BROWSERS                          │
│  (Coordinators, HOD, Dean, Head, Admin)                     │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ HTTP/HTTPS
                        │ WebSocket
                        │
┌───────────────────────▼─────────────────────────────────────┐
│                 PRESENTATION LAYER                           │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │  Login   │  │Dashboard │  │  Events  │  │ Resources│   │
│  │  Screen  │  │   View   │  │   View   │  │   View   │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
│  HTML5 + CSS3 + Vanilla JavaScript                          │
└───────────────────────┬─────────────────────────────────────┘
                        │
┌───────────────────────▼─────────────────────────────────────┐
│                 APPLICATION LAYER                            │
│  ┌────────────────────────────────────────────────────┐    │
│  │            Express.js REST API Server              │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │     Auth     │  │   Workflow   │  │  Allocation  │     │
│  │   Service    │  │    Engine    │  │    Engine    │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │  Socket.IO   │  │     RBAC     │  │   Conflict   │     │
│  │  Real-time   │  │   Control    │  │  Detection   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└───────────────────────┬─────────────────────────────────────┘
                        │
┌───────────────────────▼─────────────────────────────────────┐
│                    DATA LAYER                                │
│  ┌────────────────────────────────────────────────────┐    │
│  │              MongoDB Database                       │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │  Users   │ │  Events  │ │  Venues  │ │Resources │     │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘     │
│                                                              │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐                   │
│  │Allocation│ │ Approval │ │ Resource │                   │
│  │   Logs   │ │   Logs   │ │ Requests │                   │
│  └──────────┘ └──────────┘ └──────────┘                   │
└──────────────────────────────────────────────────────────────┘
```

## 🔄 Workflow Engine Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   EVENT LIFECYCLE                            │
└─────────────────────────────────────────────────────────────┘

  CREATE          APPROVE         ALLOCATE        RUN         COMPLETE
    │               │                │             │             │
    ▼               ▼                ▼             ▼             ▼
┌─────────┐    ┌─────────┐    ┌─────────┐   ┌─────────┐   ┌─────────┐
│         │    │  HOD    │    │Resource │   │ Event   │   │Release  │
│Coordinator    │Review   │    │Allocation   │Running  │   │Resources│
│ Submits │───▶│         │───▶│Engine   │──▶│         │──▶│         │
│         │    │         │    │         │   │         │   │         │
└─────────┘    └────┬────┘    └─────────┘   └─────────┘   └─────────┘
                    │
                    ▼
               ┌─────────┐
               │  Dean   │
               │ Review  │
               └────┬────┘
                    │
                    ▼
               ┌─────────┐
               │  Head   │
               │ Review  │
               └────┬────┘
                    │
                    ▼
               [APPROVED]

           ┌──────────────┐
           │   REJECTED   │◀── Can happen at any approval stage
           │              │
           │  Resources   │
           │ Not Reserved │
           └──────────────┘
```

## 🔐 Authentication & Authorization Flow

```
┌──────────────────────────────────────────────────────────────┐
│                    AUTHENTICATION FLOW                        │
└──────────────────────────────────────────────────────────────┘

     USER                    SERVER                   DATABASE
      │                        │                          │
      │  POST /auth/login      │                          │
      ├───────────────────────▶│                          │
      │  email + password      │                          │
      │                        │   Query User             │
      │                        ├─────────────────────────▶│
      │                        │                          │
      │                        │◀─────────────────────────┤
      │                        │   User Data              │
      │                        │                          │
      │                        │  Verify Password         │
      │                        │  (bcrypt)                │
      │                        │                          │
      │                        │  Generate JWT            │
      │                        │                          │
      │  JWT Token + User      │                          │
      │◀───────────────────────┤                          │
      │                        │                          │
      │                        │                          │
      │  Subsequent Requests   │                          │
      │  Authorization: Bearer │                          │
      ├───────────────────────▶│                          │
      │                        │                          │
      │                        │  Verify JWT              │
      │                        │                          │
      │  Protected Data        │                          │
      │◀───────────────────────┤                          │
      │                        │                          │
```

## 📊 Resource Allocation Algorithm

```
┌──────────────────────────────────────────────────────────────┐
│              ALLOCATION ENGINE WORKFLOW                       │
└──────────────────────────────────────────────────────────────┘

                        Event Approved
                             │
                             ▼
                  ┌────────────────────┐
                  │  Check Venue       │
                  │  Capacity          │
                  └──────┬─────────────┘
                         │
                    ┌────┴────┐
                    │         │
           Sufficient   Insufficient
                    │         │
                    │         ▼
                    │    ┌─────────────────┐
                    │    │  Reject with    │
                    │    │  Capacity Error │
                    │    └─────────────────┘
                    │
                    ▼
          ┌─────────────────────┐
          │  Check Resource     │
          │  Availability       │
          └──────┬──────────────┘
                 │
            ┌────┴────┐
            │         │
      Available   Unavailable
            │         │
            │         ▼
            │    ┌─────────────────┐
            │    │  Suggest        │
            │    │  Alternatives   │
            │    └─────────────────┘
            │
            ▼
    ┌──────────────────┐
    │  Check Time      │
    │  Conflicts       │
    └──────┬───────────┘
           │
      ┌────┴────┐
      │         │
   No Conflicts  Has Conflicts
      │         │
      │         ▼
      │    ┌─────────────────┐
      │    │  Return         │
      │    │  Conflicting    │
      │    │  Events         │
      │    └─────────────────┘
      │
      ▼
┌──────────────────┐
│  Allocate:       │
│  - Reserve Venue │
│  - Deduct        │
│    Resources     │
│  - Create        │
│    Allocation    │
│    Record        │
└──────────────────┘
      │
      ▼
┌──────────────────┐
│  Notify Users    │
│  (Socket.IO)     │
└──────────────────┘
```

## 🌐 Real-Time Communication

```
┌──────────────────────────────────────────────────────────────┐
│                  SOCKET.IO ARCHITECTURE                       │
└──────────────────────────────────────────────────────────────┘

   CLIENT 1         CLIENT 2         SERVER         DATABASE
      │                │                │                │
      │  Connect       │                │                │
      ├────────────────┼───────────────▶│                │
      │                │                │                │
      │                │  Connect       │                │
      │                ├───────────────▶│                │
      │                │                │                │
      │  Create Event  │                │                │
      ├────────────────┼───────────────▶│                │
      │                │                │   Save Event   │
      │                │                ├───────────────▶│
      │                │                │                │
      │                │                │  Broadcast     │
      │                │◀───────────────┤  event_created │
      │◀───────────────┤                │                │
      │                │                │                │
      │                │  Approve Event │                │
      │                ├───────────────▶│                │
      │                │                │   Update       │
      │                │                ├───────────────▶│
      │                │                │                │
      │                │                │  Broadcast     │
      │                │◀───────────────┤  event_approved│
      │◀───────────────┤                │                │
      │                │                │                │
   [UI Updates]    [UI Updates]       │                │
   Automatically   Automatically      │                │
```

## 🗄️ Database Schema Relationships

```
┌─────────────────────────────────────────────────────────────┐
│                   DATA MODEL DIAGRAM                         │
└─────────────────────────────────────────────────────────────┘

     ┌──────────┐
     │  USERS   │
     │          │
     │ _id      │◀────────────────┐
     │ name     │                 │
     │ email    │                 │ coordinator_id
     │ role     │                 │
     └──────────┘                 │
          │                       │
          │ approved_by      ┌────┴─────┐
          │                  │  EVENTS  │
          │                  │          │
          │                  │ _id      │
          │                  │ title    │
          └─────────────────▶│ status   │
                             │ ...      │
                             └────┬─────┘
                                  │
                ┌─────────────────┼─────────────────┐
                │ event_id        │ event_id        │ event_id
                │                 │                 │
         ┌──────▼──────┐   ┌──────▼──────┐   ┌─────▼───────┐
         │EVENT_        │   │ALLOCATIONS  │   │APPROVAL_LOG │
         │RESOURCE_     │   │             │   │             │
         │REQUEST       │   │ venue_id    │   │approved_by  │
         │              │   │ resource_   │   │ decision    │
         │resource_id   │   │ allocations │   │ comments    │
         └──────┬───────┘   └──────┬──────┘   └─────────────┘
                │                  │
                │                  │ venue_id
                │ resource_id      │
                │                  │
         ┌──────▼──────┐    ┌──────▼──────┐
         │ RESOURCES   │    │   VENUES    │
         │             │    │             │
         │ _id         │    │ _id         │
         │ name        │    │ name        │
         │ available_  │    │ capacity    │
         │ quantity    │    │ status      │
         └─────────────┘    └─────────────┘
```

## 🔒 Security Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                    SECURITY LAYERS                            │
└──────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  Layer 1: Authentication                                     │
│  ┌────────────────────────────────────────────────────┐    │
│  │ JWT Token Verification                              │    │
│  │ - Token expiration check                            │    │
│  │ - Signature validation                              │    │
│  │ - User existence verification                       │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────┐
│  Layer 2: Authorization (RBAC)                              │
│  ┌────────────────────────────────────────────────────┐    │
│  │ Role-Based Access Control                           │    │
│  │ - Coordinator: Create events, own data             │    │
│  │ - HOD: Department-level access                     │    │
│  │ - Dean: School-level access                        │    │
│  │ - Head: Institution-wide access                    │    │
│  │ - Admin: Full system access                        │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────┐
│  Layer 3: Data Validation                                   │
│  ┌────────────────────────────────────────────────────┐    │
│  │ Input Sanitization                                  │    │
│  │ - Mongoose schema validation                       │    │
│  │ - Type checking                                    │    │
│  │ - Required field enforcement                       │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────┐
│  Layer 4: Password Security                                 │
│  ┌────────────────────────────────────────────────────┐    │
│  │ bcrypt Hashing                                      │    │
│  │ - Salt rounds: 10                                  │    │
│  │ - One-way encryption                               │    │
│  │ - Secure password comparison                       │    │
│  └────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## 📈 Scalability Considerations

### Horizontal Scaling
```
       Load Balancer
            │
    ┌───────┼───────┐
    │       │       │
  Node1   Node2   Node3
    │       │       │
    └───────┼───────┘
            │
       MongoDB Cluster
```

### Microservices Architecture (Future)
```
API Gateway
    │
    ├── Auth Service
    ├── Event Service
    ├── Resource Service
    ├── Notification Service
    └── Analytics Service
```

## 🎯 Design Patterns Used

1. **MVC Pattern**: Model-View-Controller separation
2. **Repository Pattern**: Data access abstraction
3. **Observer Pattern**: Real-time notifications (Socket.IO)
4. **Strategy Pattern**: Approval workflow engine
5. **Singleton Pattern**: Database connection
6. **Factory Pattern**: Model creation
7. **Middleware Pattern**: Express.js middleware chain

---

This architecture ensures:
- ✅ Scalability
- ✅ Maintainability
- ✅ Security
- ✅ Real-time capabilities
- ✅ Clear separation of concerns
- ✅ Easy testing and debugging
